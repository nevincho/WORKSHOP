# TANGRA LoRa / EDGE LINK Protocol v1 — LORA-02

Status: reference codec / mock transport only. No RF, serial, Pi, Dashboard, WIDE payload, command, IFF, readiness or actuation integration.

## Envelope
All multi-byte integers are big-endian.

| Offset | Field | Width | Semantics |
|---|---:|---:|---|
| 0 | magic | 2 | ASCII `TG`; self-identification only |
| 2 | protocol_version | 1 | `1` |
| 3 | message_type | 1 | v1 IDs 1..5 |
| 4 | envelope_flags | 1 | bit0 timestamp present; bits1..7 zero in v1 |
| 5 | source_id | 2 | opaque TANGRA node/source identity; not target/track/radio address authority |
| 7 | session_id | 4 | runtime-session token; changes on source runtime restart |
| 11 | sequence | 2 | one global per-source/per-session packet sequence |
| 13 | source_uptime_s | 4 | unsigned seconds since source runtime/session start |
| 17 | payload_len | 1 | payload bytes only |
| 18 | source_timestamp_ms | 0/4 | optional source-local timestamp; epoch unspecified; not UTC authority |
| ... | payload | N | class-specific |
| final | CRC16 | 2 | CRC-16/CCITT-FALSE over every prior byte |

Base overhead is 20 bytes without timestamp, 24 bytes with timestamp, including CRC.
Maximum packet size is 192 bytes.

## Message IDs
1 HEARTBEAT; 2 TARGET; 3 SPATIAL; 4 EVENT; 5 DIAGNOSTIC. IDs 6..255 reserved. Unknown core message IDs are rejected. There is no WIDE core type.

## Versioning and extension
Unknown protocol versions are rejected as incompatible. Within v1, every payload begins with a one-byte presence/flags field. Bit7 means a compatible extension area follows known v1 fields: `ext_len:u8`, then zero or more TLVs `tag:u8,len:u8,value:len`. v1 validates and skips unknown extension TLVs. With bit7 clear, trailing bytes are prohibited. Envelope flag changes that alter parsing require a protocol-version bump.

## Sequence/session
`sequence` is initialized to 0 for a new `session_id`, increments by one for every packet regardless of class, and wraps 65535→0. Duplicate/out-of-order reasoning is only within equal `(source_id,session_id)` and uses 16-bit serial arithmetic at the receiver. `session_id` is a 32-bit restart token supplied by the source runtime and must change on runtime restart. Combined `(source_id,session_id,sequence,source_uptime_s)` distinguishes normal progression, wrap, restart, and stale packets without synchronized clocks. Retransmission policy is outside LORA-02.

## Timestamp
Optional `source_timestamp_ms` is unsigned 32-bit milliseconds in a source-local clock domain/epoch. It is only comparable when the implementation knows the samples share that clock domain. It is never silently interpreted as UTC. Absence is valid.

## Numeric encodings
Overflow is rejected by encoder. Decoder rejects malformed shapes/enums.

### HEARTBEAT
Payload: `flags:u8` bit0 active_track_count present; `runtime_state:u8`; `cpu_usage:u16`; `ram_usage:u16`; `cpu_temperature:i16`; `runtime_fps:u16`; `hq_state:u8`; `detector_state:u8`; `ca_authority:u8`; optional `active_track_count:u8`.

`runtime_uptime_s` is not duplicated: the HEARTBEAT semantic field is carried by envelope `source_uptime_s` and encode rejects mismatch.

- cpu_usage: source numeric value ×10; wire resolution 0.1 source-unit; range 0..6553.5 source-units. This does not assert percent/system/process semantics.
- ram_usage: source numeric value ×10; same non-strengthening rule; 0..6553.5.
- cpu_temperature: source numeric value ×10; signed; -3276.8..3276.7 source-units. This does not strengthen the source unit contract.
- runtime_fps: frames/s ×10; 0..6553.5 fps.

### TARGET
Payload: `flags:u8` bit0 target_class, bit1 continuity_state; `target_ref_len:u8`; `target_ref:1..16 bytes`; `identity_provenance:u8`; `tracking_state:u8`; optional `target_class:u16`; optional `continuity_state:u8`.

`target_ref` is opaque continuity data, never interpreted as NanoTracker identity by codec.

### SPATIAL
Payload flags: bit0 XYZ, bit1 velocity, bit2 range, bit3 uncertainty.
Then `target_ref`, `observation_reference:u32`, `metric_usable:u8 bool`, `physical_metric_state:u8`, `validity:u8`, `spatial_provenance:u8`, followed by optionals in fixed order.

- XYZ: three `i32`, metres ×100; 0.01 m resolution; -21,474,836.48..21,474,836.47 m each.
- velocity: three `i16`, m/s ×100; 0.01 m/s; -327.68..327.67 m/s each.
- range: `u32`, metres ×100; 0.01 m; 0..42,949,672.95 m.
- uncertainty: `u16`, metres ×100; 0.01 m; 0..655.35 m.

Absence is controlled only by flags. Zero is a valid present value. Invalid metric state may omit XYZ/range; codec does not synthesize missing metric data. Provenance/validity/physical state are always carried.

### EVENT
Payload: flags bit0 subject_ref, bit1 payload; `event_type:u16`; `event_reference:u32`; optional subject_ref; optional `payload_len:u8 + payload` (max 128 bytes). `event_type=0` reserved. `0x0001..0x0FFF` core/general; `0x1000..0x1FFF` reserved for future WIDE-originated events; remaining nonzero IDs available by future registry. Unknown nonzero event IDs decode generically and cannot crash v1. No WIDE payload is defined here.

### DIAGNOSTIC
Payload: `flags:u8`; `diagnostic_type:u8`; `record_count:u8` (0..8); repeated `metric_id:u8 + value:i32`. Metric IDs are a bounded registry; duplicates are rejected. No strings and no arbitrary key/value tunnel. v1 includes runtime timing, Hailo timing, HOROS status, telemetry-error and metric-context categories/metric IDs.

## Enums
Unknown enum values are rejected.

- RuntimeState: UNKNOWN=0 STARTING=1 RUNNING=2 STOPPED=3 ERROR=4
- HQState / DetectorState: UNKNOWN=0 AVAILABLE=1 UNAVAILABLE=2 ERROR=3
- CAAuthority: UNKNOWN=0 CA_PRIMARY=1 OTHER=2
- TrackingState: UNKNOWN=0 DETECTED=1 TRACKING=2 LOST=3
- ContinuityState: UNKNOWN=0 ACTIVE=1 HELD=2 LOST=3
- ValidityState: UNKNOWN=0 VALID=1 INVALID=2 DEGRADED=3
- PhysicalMetricState: UNKNOWN=0 PHYSICAL=1 PROVISIONAL=2 NON_PHYSICAL=3 UNAVAILABLE=4
- IdentityProvenance: UNKNOWN=0 GLOBAL_OBJECT_UID=1 CURRENT_TARGET_ID=2 OBJECT_ID=3 GLOBAL_TRACK_UID=4 OTHER=255
- SpatialProvenance: UNKNOWN=0 HOROS=1 MONOCULAR_CLASS_SIZE=2 RANGE_ESTIMATOR=3 OTHER=255

## Integrity
CRC-16/CCITT-FALSE: polynomial 0x1021, init 0xFFFF, refin=false, refout=false, xorout=0. Stored final two bytes big-endian. Corruption causes `BAD_CRC`. This is corruption detection only, not authentication or cryptographic security.

## Decoder contract
`decode(untrusted_bytes)` returns `DecodeResult(ok=False,error=...)`; ordinary malformed input is contained and no exception escapes the API. It rejects empty/truncated/oversized/bad magic/bad version/unknown message/bad envelope flags/bad length/bad CRC/invalid payload flags/invalid enum/impossible shapes/trailing garbage.
