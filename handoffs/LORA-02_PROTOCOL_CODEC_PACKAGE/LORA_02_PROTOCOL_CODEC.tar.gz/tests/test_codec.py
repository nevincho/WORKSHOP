import unittest, struct
from tangra_lora_v1 import *

META=EnvelopeMeta(0x1234,0x89ABCDEF,42,12345,987654)

def rt(msg,meta=META):
    b=encode(meta,msg); r=decode(b); assert r.ok, r.error; return b,r.packet.message,r.packet.meta

class CodecTests(unittest.TestCase):
    def test_heartbeat_roundtrip(self):
        m=Heartbeat(RuntimeState.RUNNING,12345,12.3,45.6,57.4,42.1,HQState.AVAILABLE,DetectorState.AVAILABLE,CAAuthority.CA_PRIMARY,3)
        b,d,meta=rt(m); self.assertEqual(d,m); self.assertEqual(meta,META)
    def test_heartbeat_optional_absent(self):
        m=Heartbeat(RuntimeState.RUNNING,12345,0,0,-10,0,HQState.UNKNOWN,DetectorState.UNKNOWN,CAAuthority.UNKNOWN,None)
        self.assertEqual(rt(m)[1],m)
    def test_target_roundtrip(self):
        m=Target(b'ct-17',IdentityProvenance.CURRENT_TARGET_ID,TrackingState.TRACKING,7,ContinuityState.ACTIVE)
        self.assertEqual(rt(m)[1],m)
    def test_target_optionals_absent(self):
        m=Target(b'x',IdentityProvenance.OTHER,TrackingState.DETECTED)
        self.assertEqual(rt(m)[1],m)
    def test_spatial_roundtrip_all(self):
        m=Spatial(b'ct-17',100,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,(12.34,-5.67,0.0),(1.2,-2.3,3.4),42.5,1.25)
        self.assertEqual(rt(m)[1],m)
    def test_spatial_absent_metric(self):
        m=Spatial(b'x',0,False,PhysicalMetricState.UNAVAILABLE,ValidityState.INVALID,SpatialProvenance.HOROS)
        self.assertEqual(rt(m)[1],m)
    def test_zero_is_valid(self):
        m=Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,(0,0,0),(0,0,0),0,0)
        self.assertEqual(rt(m)[1],m)
    def test_event_roundtrip(self):
        m=Event(0x1001,99,b'x',b'abc')
        self.assertEqual(rt(m)[1],m)
    def test_unknown_event_type_survives(self):
        m=Event(0x4567,1,None,b'z')
        self.assertEqual(rt(m)[1],m)
    def test_diag_roundtrip(self):
        m=Diagnostic(DiagnosticType.HAILO_TIMING,(DiagnosticRecord(DiagnosticMetric.HAILO_INFERENCE_MS_X10,229),))
        self.assertEqual(rt(m)[1],m)
    def test_mock_transport(self):
        m=Target(b'x',IdentityProvenance.OBJECT_ID,TrackingState.TRACKING)
        b=encode(META,m); t=MockByteTransport(); t.send(b); self.assertEqual(decode(t.receive()).packet.message,m)
    def test_sequence_wrap_values(self):
        for seq in (0,65535):
            meta=EnvelopeMeta(1,2,seq,5,None); m=Event(1,1); self.assertTrue(decode(encode(meta,m)).ok)
    def test_restart_distinction(self):
        m=Event(1,1)
        a=decode(encode(EnvelopeMeta(1,100,10,500),m)).packet.meta
        b=decode(encode(EnvelopeMeta(1,101,0,1),m)).packet.meta
        self.assertNotEqual(a.session_id,b.session_id)
    def test_heartbeat_uptime_mismatch_rejected(self):
        with self.assertRaises(CodecError): encode(META,Heartbeat(RuntimeState.RUNNING,9,1,1,1,1,HQState.AVAILABLE,DetectorState.AVAILABLE,CAAuthority.CA_PRIMARY))
    def test_ref_min_max(self):
        for ref in (b'a',b'1'*16): self.assertEqual(rt(Target(ref,IdentityProvenance.OTHER,TrackingState.UNKNOWN))[1].target_ref,ref)
    def test_ref_overflow(self):
        with self.assertRaises(CodecError): encode(META,Target(b'x'*17,IdentityProvenance.OTHER,TrackingState.UNKNOWN))
    def test_cpu_boundary(self):
        base=dict(runtime_state=RuntimeState.RUNNING,runtime_uptime_s=12345,ram_usage=1,cpu_temperature=0,runtime_fps=1,hq_state=HQState.AVAILABLE,detector_state=DetectorState.AVAILABLE,ca_authority=CAAuthority.CA_PRIMARY)
        for v in (0,6553.5,12.3): self.assertTrue(decode(encode(META,Heartbeat(cpu_usage=v,**base))).ok)
        with self.assertRaises(CodecError): encode(META,Heartbeat(cpu_usage=6553.6,**base))
    def test_temp_boundary(self):
        base=dict(runtime_state=RuntimeState.RUNNING,runtime_uptime_s=12345,cpu_usage=1,ram_usage=1,runtime_fps=1,hq_state=HQState.AVAILABLE,detector_state=DetectorState.AVAILABLE,ca_authority=CAAuthority.CA_PRIMARY)
        for v in (-3276.8,3276.7,0): self.assertTrue(decode(encode(META,Heartbeat(cpu_temperature=v,**base))).ok)
        with self.assertRaises(CodecError): encode(META,Heartbeat(cpu_temperature=3276.8,**base))
    def test_xyz_boundary(self):
        m=Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,(-21474836.48,21474836.47,0))
        self.assertTrue(decode(encode(META,m)).ok)
        with self.assertRaises(CodecError): encode(META,Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,(21474836.48,0,0)))
    def test_velocity_boundary(self):
        m=Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,velocity_mps=(-327.68,327.67,0))
        self.assertTrue(decode(encode(META,m)).ok)
        with self.assertRaises(CodecError): encode(META,Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,velocity_mps=(327.68,0,0)))
    def test_range_boundary(self):
        for v in (0,42949672.95,12.34): self.assertTrue(decode(encode(META,Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,range_m=v))).ok)
        with self.assertRaises(CodecError): encode(META,Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,range_m=42949672.96))
    def test_unc_boundary(self):
        for v in (0,655.35,1.2): self.assertTrue(decode(encode(META,Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,uncertainty_m=v))).ok)
        with self.assertRaises(CodecError): encode(META,Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS,uncertainty_m=655.36))
    def test_empty(self): self.assertEqual(decode(b'').error,'EMPTY')
    def test_truncated_header(self): self.assertEqual(decode(b'TG\x01').error,'TRUNCATED')
    def test_oversized(self): self.assertEqual(decode(b'x'*193).error,'OVERSIZED')
    def test_bad_magic(self):
        b=bytearray(encode(META,Event(1,1))); b[0]=0; self.assertEqual(decode(bytes(b)).error,'BAD_MAGIC')
    def test_bad_version(self):
        b=bytearray(encode(META,Event(1,1))); b[2]=2; self.assertEqual(decode(bytes(b)).error,'UNSUPPORTED_VERSION')
    def test_bad_type(self):
        b=bytearray(encode(META,Event(1,1))); b[3]=99; self.assertEqual(decode(bytes(b)).error,'UNKNOWN_TYPE')
    def test_invalid_env_flags(self):
        b=bytearray(encode(META,Event(1,1))); b[4]=0x80; self.assertEqual(decode(bytes(b)).error,'INVALID_FLAGS')
    def test_bad_length(self):
        b=bytearray(encode(META,Event(1,1))); b[17]=(b[17]+1)&255; self.assertEqual(decode(bytes(b)).error,'BAD_LENGTH')
    def test_bad_crc(self):
        b=bytearray(encode(META,Event(1,1))); b[-1]^=1; self.assertEqual(decode(bytes(b)).error,'BAD_CRC')
    def test_single_byte_corruption(self):
        b=bytearray(encode(META,Target(b'x',IdentityProvenance.OBJECT_ID,TrackingState.TRACKING))); b[-3]^=1; self.assertEqual(decode(bytes(b)).error,'BAD_CRC')
    def test_truncated_crc(self):
        b=encode(META,Event(1,1))[:-1]; self.assertEqual(decode(b).error,'BAD_LENGTH')
    def test_invalid_enum(self):
        b=bytearray(encode(META,Heartbeat(RuntimeState.RUNNING,12345,1,1,1,1,HQState.AVAILABLE,DetectorState.AVAILABLE,CAAuthority.CA_PRIMARY)))
        payload_off=22 # timestamp present, header 18 + timestamp 4
        b[payload_off+1]=99
        crc=crc16_ccitt_false(bytes(b[:-2])); b[-2:]=struct.pack('>H',crc)
        self.assertEqual(decode(bytes(b)).error,'INVALID_ENUM')
    def test_invalid_payload_flags(self):
        b=bytearray(encode(META,Event(1,1))); off=22; b[off]=0x40; b[-2:]=struct.pack('>H',crc16_ccitt_false(bytes(b[:-2]))); self.assertEqual(decode(bytes(b)).error,'INVALID_PAYLOAD')
    def test_trailing_garbage_detected_by_length(self):
        b=encode(META,Event(1,1))+b'X'; self.assertEqual(decode(b).error,'BAD_LENGTH')
    def test_event_payload_limit(self):
        self.assertTrue(decode(encode(META,Event(1,1,payload=b'x'*128))).ok)
        with self.assertRaises(CodecError): encode(META,Event(1,1,payload=b'x'*129))
    def test_diag_count_limit(self):
        rec=tuple(DiagnosticRecord(DiagnosticMetric.LOOP_MS_X10,i) for i in range(1))
        self.assertTrue(decode(encode(META,Diagnostic(DiagnosticType.RUNTIME_TIMING,rec))).ok)
    def test_packet_size_limit(self):
        # event maximum stays below protocol maximum
        self.assertLessEqual(len(encode(META,Event(1,1,b'x'*16,b'y'*128))),MAX_PACKET_SIZE)
    def test_timestamp_absent(self):
        meta=EnvelopeMeta(1,2,3,4,None); r=decode(encode(meta,Event(1,1))); self.assertTrue(r.ok); self.assertIsNone(r.packet.meta.source_timestamp_ms)
    def test_source_boundaries(self):
        for sid in (0,65535): self.assertTrue(decode(encode(EnvelopeMeta(sid,0,0,0),Event(1,1))).ok)
    def test_session_boundaries(self):
        for sess in (0,0xFFFFFFFF): self.assertTrue(decode(encode(EnvelopeMeta(1,sess,0,0),Event(1,1))).ok)
    def test_uptime_boundaries(self):
        for up in (0,0xFFFFFFFF): self.assertTrue(decode(encode(EnvelopeMeta(1,1,0,up),Event(1,1))).ok)
    def test_timestamp_boundaries(self):
        for ts in (0,0xFFFFFFFF): self.assertTrue(decode(encode(EnvelopeMeta(1,1,0,0,ts),Event(1,1))).ok)
    def test_event_zero_type_rejected(self):
        with self.assertRaises(CodecError): encode(META,Event(0,1))
    def test_bool_corruption_rejected(self):
        b=bytearray(encode(META,Spatial(b'x',1,True,PhysicalMetricState.PHYSICAL,ValidityState.VALID,SpatialProvenance.HOROS)))
        off=22; # flags + ref len + ref + obs = 1+1+1+4 => metric at +7
        b[off+7]=2; b[-2:]=struct.pack('>H',crc16_ccitt_false(bytes(b[:-2]))); self.assertEqual(decode(bytes(b)).error,'INVALID_PAYLOAD')
    def test_decode_never_raises_random_short(self):
        for n in range(40): self.assertIsInstance(decode(bytes(range(n))),DecodeResult)

if __name__=='__main__': unittest.main()
