# File Manifest
- `PROTOCOL_SPEC.md` exact v1 wire contract
- `tangra_lora_v1/models.py` semantic models/enums
- `tangra_lora_v1/codec.py` encoder/decoder + CRC + validation
- `tangra_lora_v1/mock_transport.py` in-memory bytes-only transport
- `tangra_lora_v1/__init__.py` package exports
- `tests/test_codec.py` deterministic test suite
- `fixtures/v1_vectors.json` canonical fixture vectors
- `fixtures/performance.json` codec-only measurement
- `README.md` package boundary/run command
