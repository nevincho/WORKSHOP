# LORA-02 Protocol + Codec Reference Package

Isolated reference package for the accepted LORA-01 state contract. It contains semantic models/enums, deterministic binary codec, CRC, mock byte transport, tests, fixtures, protocol spec and performance evidence. It has no hardware/radio/socket/serial dependency and does not modify TANGRA runtime or Dashboard.

Run: `PYTHONPATH=. python -m unittest discover -s tests -p 'test*.py' -v`
